"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import Footer from "@/components/footer"
import AdminDashboard from "@/components/admin-dashboard"
import AdminLogin from "@/components/admin-login"

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const auth = localStorage.getItem("adminAuth")
    if (auth === "true") {
      setIsAuthenticated(true)
    }
    setIsLoading(false)
  }, [])

  if (isLoading) {
    return <div className="min-h-screen bg-background" />
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      {isAuthenticated ? (
        <AdminDashboard
          onLogout={() => {
            setIsAuthenticated(false)
            localStorage.removeItem("adminAuth")
          }}
        />
      ) : (
        <AdminLogin
          onLogin={() => {
            setIsAuthenticated(true)
            localStorage.setItem("adminAuth", "true")
          }}
        />
      )}
      <Footer />
    </main>
  )
}
