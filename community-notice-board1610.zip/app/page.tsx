"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import Hero from "@/components/hero"
import AnnouncementsSection from "@/components/announcements-section"
import EventsSection from "@/components/events-section"
import ContactsSection from "@/components/contacts-section"
import Footer from "@/components/footer"

export default function Home() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    setIsLoading(false)
  }, [])

  if (isLoading) {
    return <div className="min-h-screen bg-background" />
  }

  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <Hero />
      <AnnouncementsSection />
      <EventsSection />
      <ContactsSection />
      <Footer />
    </main>
  )
}
