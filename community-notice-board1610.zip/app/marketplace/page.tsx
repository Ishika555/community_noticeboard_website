"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import Footer from "@/components/footer"
import { Search, Plus } from "lucide-react"
import Link from "next/link"

interface Listing {
  id: string
  title: string
  category: "Buy" | "Sell" | "Rent"
  price: string
  description: string
  contact: string
  date: string
}

export default function MarketplacePage() {
  const [listings, setListings] = useState<Listing[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState<"All" | "Buy" | "Sell" | "Rent">("All")

  useEffect(() => {
    const stored = localStorage.getItem("marketplace")
    if (stored) {
      setListings(JSON.parse(stored))
    } else {
      const defaults: Listing[] = [
        {
          id: "1",
          title: "Bicycle - Good Condition",
          category: "Sell",
          price: "₹2,000",
          description: "Mountain bike, 2 years old, well maintained",
          contact: "Sonam - 9990625629",
          date: new Date().toISOString(),
        },
        {
          id: "2",
          title: "Looking for Tuition Classes",
          category: "Buy",
          price: "Negotiable",
          description: "Mathematics tuition for class 10 student",
          contact: "Vaani - 9810217758",
          date: new Date().toISOString(),
        },
      ]
      setListings(defaults)
      localStorage.setItem("marketplace", JSON.stringify(defaults))
    }
  }, [])

  const filtered = listings.filter((l) => {
    const matchesSearch =
      l.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || l.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      <section className="py-12 bg-muted border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Buy/Sell/Rent</h1>
          <p className="text-muted-foreground">Community marketplace for buying, selling, and renting items</p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
              <input
                type="text"
                placeholder="Search listings..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <Link
              href="/admin"
              className="flex items-center gap-2 bg-primary text-background px-4 py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              <Plus size={20} />
              New Listing
            </Link>
          </div>

          <div className="flex gap-2 mb-8">
            {(["All", "Buy", "Sell", "Rent"] as const).map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-lg transition ${
                  selectedCategory === cat
                    ? "bg-primary text-background"
                    : "bg-muted text-foreground border border-border hover:bg-muted/80"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filtered.length > 0 ? (
              filtered.map((listing) => (
                <div
                  key={listing.id}
                  className="bg-muted rounded-lg border border-border hover:shadow-lg transition overflow-hidden p-6"
                >
                  <div className="flex items-start justify-between mb-3">
                    <h3 className="text-lg font-semibold text-foreground flex-1">{listing.title}</h3>
                    <span
                      className={`text-xs px-3 py-1 rounded font-medium ${
                        listing.category === "Sell"
                          ? "bg-green-100 text-green-800"
                          : listing.category === "Buy"
                            ? "bg-blue-100 text-blue-800"
                            : "bg-orange-100 text-orange-800"
                      }`}
                    >
                      {listing.category}
                    </span>
                  </div>
                  <p className="text-lg font-bold text-primary mb-2">{listing.price}</p>
                  <p className="text-muted-foreground text-sm mb-3">{listing.description}</p>
                  <div className="pt-3 border-t border-border">
                    <p className="text-xs text-muted-foreground">📞 {listing.contact}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <p className="text-muted-foreground text-lg">No listings found</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
