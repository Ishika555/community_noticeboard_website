"use client"

import { useState, useEffect } from "react"
import Navigation from "@/components/navigation"
import Footer from "@/components/footer"
import { Search, Plus } from "lucide-react"
import Link from "next/link"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  description: string
}

export default function EventsPage() {
  const [events, setEvents] = useState<Event[]>([])
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const stored = localStorage.getItem("events")
    if (stored) {
      setEvents(JSON.parse(stored))
    }
  }, [])

  const filtered = events.filter(
    (e) =>
      e.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      e.description.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const sortedEvents = [...filtered].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())

  return (
    <main className="min-h-screen bg-background">
      <Navigation />

      <section className="py-12 bg-muted border-b border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-4xl font-bold text-foreground mb-2">Community Events</h1>
          <p className="text-muted-foreground">Discover upcoming events in your community</p>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 text-muted-foreground" size={20} />
              <input
                type="text"
                placeholder="Search events..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <Link
              href="/admin"
              className="flex items-center gap-2 bg-primary text-background px-4 py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              <Plus size={20} />
              New Event
            </Link>
          </div>

          <div className="space-y-4">
            {sortedEvents.length > 0 ? (
              sortedEvents.map((event) => (
                <div key={event.id} className="bg-muted p-6 rounded-lg border border-border hover:shadow-lg transition">
                  <div className="flex items-start gap-4">
                    <div className="bg-primary text-background p-4 rounded-lg text-center min-w-fit">
                      <p className="text-2xl font-bold">{new Date(event.date).getDate()}</p>
                      <p className="text-xs uppercase">
                        {new Date(event.date).toLocaleDateString("en-US", { month: "short" })}
                      </p>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2">{event.title}</h3>
                      <div className="space-y-1 text-muted-foreground text-sm mb-3">
                        <p>🕐 {event.time}</p>
                        <p>📍 {event.location}</p>
                      </div>
                      <p className="text-muted-foreground">{event.description}</p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No events found</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  )
}
