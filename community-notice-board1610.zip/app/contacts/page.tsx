"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"

interface Contact {
  id: string
  name: string
  role: string
  phone: string
  email: string
}

const defaultContacts: Contact[] = [
  {
    id: "1",
    name: "Sonam Jha",
    role: "Society President",
    phone: "9990625629",
    email: "sonam.jha@community.com",
  },
  {
    id: "2",
    name: "Vaani Sharma",
    role: "Secretary",
    phone: "9810217758",
    email: "vaani.sharma@community.com",
  },
  {
    id: "3",
    name: "Aman Tomar",
    role: "Maintenance Head",
    phone: "9818196477",
    email: "aman.tomar@community.com",
  },
]

export default function ContactsPage() {
  const [contacts, setContacts] = useState<Contact[]>(defaultContacts)
  const [searchTerm, setSearchTerm] = useState("")

  useEffect(() => {
    const savedContacts = localStorage.getItem("contacts")
    if (savedContacts) {
      try {
        setContacts(JSON.parse(savedContacts))
      } catch (error) {
        setContacts(defaultContacts)
      }
    }
  }, [])

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      contact.role.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <main className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-12">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-foreground mb-2">Important Contacts</h1>
          <p className="text-lg text-muted-foreground">Get in touch with our society management team</p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <Input
            placeholder="Search contacts by name or role..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md"
          />
        </div>

        {/* Contacts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredContacts.length > 0 ? (
            filteredContacts.map((contact) => (
              <Card key={contact.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl">{contact.name}</CardTitle>
                  <CardDescription className="text-base">{contact.role}</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Phone</p>
                    <a href={`tel:${contact.phone}`} className="text-primary hover:underline font-medium">
                      📞 {contact.phone}
                    </a>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground mb-1">Email</p>
                    <a href={`mailto:${contact.email}`} className="text-primary hover:underline font-medium break-all">
                      ✉️ {contact.email}
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <p className="text-muted-foreground text-lg">No contacts found</p>
            </div>
          )}
        </div>
      </div>
    </main>
  )
}
