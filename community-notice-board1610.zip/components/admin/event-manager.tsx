"use client"

import { useState, useEffect } from "react"
import { Trash2, Edit2 } from "lucide-react"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  description: string
}

export default function EventManager() {
  const [events, setEvents] = useState<Event[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    date: "",
    time: "",
    location: "",
    description: "",
  })

  useEffect(() => {
    const stored = localStorage.getItem("events")
    if (stored) {
      setEvents(JSON.parse(stored))
    }
  }, [])

  const saveEvents = (updated: Event[]) => {
    setEvents(updated)
    localStorage.setItem("events", JSON.stringify(updated))
  }

  const handleAdd = () => {
    if (formData.title && formData.date && formData.time && formData.location) {
      const newEvent: Event = {
        id: Date.now().toString(),
        ...formData,
      }
      saveEvents([...events, newEvent])
      setFormData({ title: "", date: "", time: "", location: "", description: "" })
    }
  }

  const handleEdit = (id: string) => {
    const event = events.find((e) => e.id === id)
    if (event) {
      setFormData(event)
      setEditingId(id)
    }
  }

  const handleUpdate = () => {
    if (editingId && formData.title && formData.date) {
      const updated = events.map((e) => (e.id === editingId ? { ...e, ...formData } : e))
      saveEvents(updated)
      setFormData({ title: "", date: "", time: "", location: "", description: "" })
      setEditingId(null)
    }
  }

  const handleDelete = (id: string) => {
    saveEvents(events.filter((e) => e.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="bg-muted p-6 rounded-lg border border-border">
        <h2 className="text-xl font-semibold text-foreground mb-4">{editingId ? "Edit Event" : "Add New Event"}</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Event Title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
            <input
              type="time"
              value={formData.time}
              onChange={(e) => setFormData({ ...formData, time: e.target.value })}
              className="px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <input
            type="text"
            placeholder="Location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={3}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <div className="flex gap-2">
            <button
              onClick={editingId ? handleUpdate : handleAdd}
              className="flex-1 bg-primary text-background py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              {editingId ? "Update" : "Add"} Event
            </button>
            {editingId && (
              <button
                onClick={() => {
                  setEditingId(null)
                  setFormData({ title: "", date: "", time: "", location: "", description: "" })
                }}
                className="px-4 py-2 border border-border rounded-lg hover:bg-muted transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold text-foreground">All Events</h2>
        {events.map((event) => (
          <div key={event.id} className="bg-muted p-4 rounded-lg border border-border flex justify-between items-start">
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">{event.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">
                📅 {event.date} at {event.time}
              </p>
              <p className="text-sm text-muted-foreground">📍 {event.location}</p>
              <p className="text-sm text-muted-foreground mt-1">{event.description}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleEdit(event.id)} className="p-2 hover:bg-background rounded transition">
                <Edit2 size={18} className="text-primary" />
              </button>
              <button onClick={() => handleDelete(event.id)} className="p-2 hover:bg-background rounded transition">
                <Trash2 size={18} className="text-red-600" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
