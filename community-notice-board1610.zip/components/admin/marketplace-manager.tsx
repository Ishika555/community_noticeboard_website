"use client"

import { useState, useEffect } from "react"
import { Trash2, Edit2 } from "lucide-react"

interface Listing {
  id: string
  title: string
  category: "Buy" | "Sell" | "Rent"
  price: string
  description: string
  contact: string
  date: string
}

export default function MarketplaceManager() {
  const [listings, setListings] = useState<Listing[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    category: "Sell" as "Buy" | "Sell" | "Rent",
    price: "",
    description: "",
    contact: "",
  })

  useEffect(() => {
    const stored = localStorage.getItem("marketplace")
    if (stored) {
      setListings(JSON.parse(stored))
    }
  }, [])

  const saveListings = (updated: Listing[]) => {
    setListings(updated)
    localStorage.setItem("marketplace", JSON.stringify(updated))
  }

  const handleAdd = () => {
    if (formData.title && formData.price && formData.contact) {
      const newListing: Listing = {
        id: Date.now().toString(),
        ...formData,
        date: new Date().toISOString(),
      }
      saveListings([...listings, newListing])
      setFormData({ title: "", category: "Sell", price: "", description: "", contact: "" })
    }
  }

  const handleEdit = (id: string) => {
    const listing = listings.find((l) => l.id === id)
    if (listing) {
      setFormData({
        title: listing.title,
        category: listing.category,
        price: listing.price,
        description: listing.description,
        contact: listing.contact,
      })
      setEditingId(id)
    }
  }

  const handleUpdate = () => {
    if (editingId && formData.title && formData.price) {
      const updated = listings.map((l) => (l.id === editingId ? { ...l, ...formData } : l))
      saveListings(updated)
      setFormData({ title: "", category: "Sell", price: "", description: "", contact: "" })
      setEditingId(null)
    }
  }

  const handleDelete = (id: string) => {
    saveListings(listings.filter((l) => l.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="bg-muted p-6 rounded-lg border border-border">
        <h2 className="text-xl font-semibold text-foreground mb-4">{editingId ? "Edit Listing" : "Add New Listing"}</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <select
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value as "Buy" | "Sell" | "Rent" })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option>Buy</option>
            <option>Sell</option>
            <option>Rent</option>
          </select>
          <input
            type="text"
            placeholder="Price"
            value={formData.price}
            onChange={(e) => setFormData({ ...formData, price: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            rows={3}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="text"
            placeholder="Contact (Name - Phone)"
            value={formData.contact}
            onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <div className="flex gap-2">
            <button
              onClick={editingId ? handleUpdate : handleAdd}
              className="flex-1 bg-primary text-background py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              {editingId ? "Update" : "Add"} Listing
            </button>
            {editingId && (
              <button
                onClick={() => {
                  setEditingId(null)
                  setFormData({ title: "", category: "Sell", price: "", description: "", contact: "" })
                }}
                className="px-4 py-2 border border-border rounded-lg hover:bg-muted transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold text-foreground">All Listings</h2>
        {listings.map((listing) => (
          <div
            key={listing.id}
            className="bg-muted p-4 rounded-lg border border-border flex justify-between items-start"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-foreground">{listing.title}</h3>
                <span className="text-xs px-2 py-1 rounded bg-primary text-background">{listing.category}</span>
              </div>
              <p className="text-sm font-bold text-primary">{listing.price}</p>
              <p className="text-sm text-muted-foreground mt-1">{listing.description}</p>
              <p className="text-xs text-muted-foreground mt-2">📞 {listing.contact}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleEdit(listing.id)} className="p-2 hover:bg-background rounded transition">
                <Edit2 size={18} className="text-primary" />
              </button>
              <button onClick={() => handleDelete(listing.id)} className="p-2 hover:bg-background rounded transition">
                <Trash2 size={18} className="text-red-600" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
