"use client"

import { useState, useEffect } from "react"
import { Trash2, Edit2 } from "lucide-react"

interface Contact {
  id: string
  name: string
  role: string
  phone: string
  email: string
  department?: string
}

export default function ContactManager() {
  const [contacts, setContacts] = useState<Contact[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    role: "",
    phone: "",
    email: "",
    department: "Management",
  })

  useEffect(() => {
    const stored = localStorage.getItem("contacts")
    if (stored) {
      setContacts(JSON.parse(stored))
    }
  }, [])

  const saveContacts = (updated: Contact[]) => {
    setContacts(updated)
    localStorage.setItem("contacts", JSON.stringify(updated))
  }

  const handleAdd = () => {
    if (formData.name && formData.phone && formData.email) {
      const newContact: Contact = {
        id: Date.now().toString(),
        ...formData,
      }
      saveContacts([...contacts, newContact])
      setFormData({ name: "", role: "", phone: "", email: "", department: "Management" })
    }
  }

  const handleEdit = (id: string) => {
    const contact = contacts.find((c) => c.id === id)
    if (contact) {
      setFormData({
        name: contact.name,
        role: contact.role,
        phone: contact.phone,
        email: contact.email,
        department: contact.department || "Management",
      })
      setEditingId(id)
    }
  }

  const handleUpdate = () => {
    if (editingId && formData.name && formData.phone) {
      const updated = contacts.map((c) => (c.id === editingId ? { ...c, ...formData } : c))
      saveContacts(updated)
      setFormData({ name: "", role: "", phone: "", email: "", department: "Management" })
      setEditingId(null)
    }
  }

  const handleDelete = (id: string) => {
    saveContacts(contacts.filter((c) => c.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="bg-muted p-6 rounded-lg border border-border">
        <h2 className="text-xl font-semibold text-foreground mb-4">{editingId ? "Edit Contact" : "Add New Contact"}</h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="text"
            placeholder="Role"
            value={formData.role}
            onChange={(e) => setFormData({ ...formData, role: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="tel"
            placeholder="Phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <input
            type="email"
            placeholder="Email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <select
            value={formData.department}
            onChange={(e) => setFormData({ ...formData, department: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option>Management</option>
            <option>Maintenance</option>
            <option>Security</option>
            <option>Finance</option>
          </select>
          <div className="flex gap-2">
            <button
              onClick={editingId ? handleUpdate : handleAdd}
              className="flex-1 bg-primary text-background py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              {editingId ? "Update" : "Add"} Contact
            </button>
            {editingId && (
              <button
                onClick={() => {
                  setEditingId(null)
                  setFormData({ name: "", role: "", phone: "", email: "", department: "Management" })
                }}
                className="px-4 py-2 border border-border rounded-lg hover:bg-muted transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold text-foreground">All Contacts</h2>
        {contacts.map((contact) => (
          <div
            key={contact.id}
            className="bg-muted p-4 rounded-lg border border-border flex justify-between items-start"
          >
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">{contact.name}</h3>
              <p className="text-sm text-primary font-medium">{contact.role}</p>
              <p className="text-sm text-muted-foreground mt-1">📞 {contact.phone}</p>
              <p className="text-sm text-muted-foreground">✉️ {contact.email}</p>
              <p className="text-xs text-muted-foreground mt-1">{contact.department}</p>
            </div>
            <div className="flex gap-2">
              <button onClick={() => handleEdit(contact.id)} className="p-2 hover:bg-background rounded transition">
                <Edit2 size={18} className="text-primary" />
              </button>
              <button onClick={() => handleDelete(contact.id)} className="p-2 hover:bg-background rounded transition">
                <Trash2 size={18} className="text-red-600" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
