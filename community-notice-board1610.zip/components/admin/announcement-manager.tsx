"use client"

import { useState, useEffect } from "react"
import { Trash2, Edit2 } from "lucide-react"

interface Announcement {
  id: string
  title: string
  content: string
  date: string
  category: string
}

export default function AnnouncementManager() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])
  const [isAdding, setIsAdding] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({ title: "", content: "", category: "Maintenance" })

  useEffect(() => {
    const stored = localStorage.getItem("announcements")
    if (stored) {
      setAnnouncements(JSON.parse(stored))
    }
  }, [])

  const saveAnnouncements = (updated: Announcement[]) => {
    setAnnouncements(updated)
    localStorage.setItem("announcements", JSON.stringify(updated))
  }

  const handleAdd = () => {
    if (formData.title && formData.content) {
      const newAnnouncement: Announcement = {
        id: Date.now().toString(),
        title: formData.title,
        content: formData.content,
        category: formData.category,
        date: new Date().toISOString(),
      }
      saveAnnouncements([newAnnouncement, ...announcements])
      setFormData({ title: "", content: "", category: "Maintenance" })
      setIsAdding(false)
    }
  }

  const handleEdit = (id: string) => {
    const announcement = announcements.find((a) => a.id === id)
    if (announcement) {
      setFormData({ title: announcement.title, content: announcement.content, category: announcement.category })
      setEditingId(id)
    }
  }

  const handleUpdate = () => {
    if (editingId && formData.title && formData.content) {
      const updated = announcements.map((a) =>
        a.id === editingId
          ? { ...a, title: formData.title, content: formData.content, category: formData.category }
          : a,
      )
      saveAnnouncements(updated)
      setFormData({ title: "", content: "", category: "Maintenance" })
      setEditingId(null)
    }
  }

  const handleDelete = (id: string) => {
    saveAnnouncements(announcements.filter((a) => a.id !== id))
  }

  return (
    <div className="space-y-6">
      <div className="bg-muted p-6 rounded-lg border border-border">
        <h2 className="text-xl font-semibold text-foreground mb-4">
          {editingId ? "Edit Announcement" : "Add New Announcement"}
        </h2>
        <div className="space-y-4">
          <input
            type="text"
            placeholder="Title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <textarea
            placeholder="Content"
            value={formData.content}
            onChange={(e) => setFormData({ ...formData, content: e.target.value })}
            rows={4}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          />
          <select
            value={formData.category}
            onChange={(e) => setFormData({ ...formData, category: e.target.value })}
            className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option>Maintenance</option>
            <option>Meeting</option>
            <option>Event</option>
            <option>Other</option>
          </select>
          <div className="flex gap-2">
            <button
              onClick={editingId ? handleUpdate : handleAdd}
              className="flex-1 bg-primary text-background py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              {editingId ? "Update" : "Add"} Announcement
            </button>
            {editingId && (
              <button
                onClick={() => {
                  setEditingId(null)
                  setFormData({ title: "", content: "", category: "Maintenance" })
                }}
                className="px-4 py-2 border border-border rounded-lg hover:bg-muted transition"
              >
                Cancel
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="space-y-3">
        <h2 className="text-xl font-semibold text-foreground">All Announcements</h2>
        {announcements.map((announcement) => (
          <div
            key={announcement.id}
            className="bg-muted p-4 rounded-lg border border-border flex justify-between items-start"
          >
            <div className="flex-1">
              <h3 className="font-semibold text-foreground">{announcement.title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{announcement.content}</p>
              <p className="text-xs text-muted-foreground mt-2">{announcement.category}</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => handleEdit(announcement.id)}
                className="p-2 hover:bg-background rounded transition"
              >
                <Edit2 size={18} className="text-primary" />
              </button>
              <button
                onClick={() => handleDelete(announcement.id)}
                className="p-2 hover:bg-background rounded transition"
              >
                <Trash2 size={18} className="text-red-600" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
