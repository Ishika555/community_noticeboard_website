"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Bell } from "lucide-react"

interface Announcement {
  id: string
  title: string
  content: string
  date: string
  category: string
}

export default function AnnouncementsSection() {
  const [announcements, setAnnouncements] = useState<Announcement[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("announcements")
    if (stored) {
      setAnnouncements(JSON.parse(stored))
    } else {
      const defaults: Announcement[] = [
        {
          id: "1",
          title: "Maintenance Notice",
          content: "Water supply will be interrupted on Saturday from 8 AM to 2 PM for maintenance work.",
          date: new Date().toISOString(),
          category: "Maintenance",
        },
        {
          id: "2",
          title: "Community Meeting",
          content: "Monthly community meeting scheduled for next Sunday at 6 PM in the community hall.",
          date: new Date().toISOString(),
          category: "Meeting",
        },
      ]
      setAnnouncements(defaults)
      localStorage.setItem("announcements", JSON.stringify(defaults))
    }
  }, [])

  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <Bell className="text-primary" size={28} />
          <h2 className="text-3xl font-bold text-foreground">Recent Announcements</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-2 mb-8">
          {announcements.slice(0, 4).map((announcement) => (
            <div
              key={announcement.id}
              className="bg-muted rounded-lg border border-border hover:shadow-lg transition overflow-hidden p-6"
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-foreground text-lg">{announcement.title}</h3>
                <span className="text-xs bg-primary text-background px-2 py-1 rounded">{announcement.category}</span>
              </div>
              <p className="text-muted-foreground mb-3 line-clamp-2">{announcement.content}</p>
              <p className="text-xs text-muted-foreground">{new Date(announcement.date).toLocaleDateString()}</p>
            </div>
          ))}
        </div>

        <Link
          href="/announcements"
          className="inline-block bg-primary text-background px-6 py-2 rounded-lg hover:bg-primary/90 transition font-medium"
        >
          View All Announcements
        </Link>
      </div>
    </section>
  )
}
