"use client"

import { useState, useEffect } from "react"
import Link from "next/link"

interface Contact {
  id: string
  name: string
  role: string
  phone: string
  email: string
}

export default function ContactsSection() {
  const [contacts, setContacts] = useState<Contact[]>([
    {
      id: "1",
      name: "Sonam Jha",
      role: "Society President",
      phone: "+91-9990625629",
      email: "sonam.jha@community.com",
    },
    {
      id: "2",
      name: "Vaani Sharma",
      role: "Secretary",
      phone: "+91-9810217758",
      email: "vaani.sharma@community.com",
    },
    {
      id: "3",
      name: "Aman Tomar",
      role: "Maintenance Head",
      phone: "+91-9818196477",
      email: "aman.tomar@community.com",
    },
  ])

  useEffect(() => {
    const stored = localStorage.getItem("contacts")
    if (stored) {
      setContacts(JSON.parse(stored))
    } else {
      const defaults: Contact[] = [
        {
          id: "1",
          name: "Sonam Jha",
          role: "Society President",
          phone: "+91-9990625629",
          email: "sonam.jha@community.com",
        },
        {
          id: "2",
          name: "Vaani Sharma",
          role: "Secretary",
          phone: "+91-9810217758",
          email: "vaani.sharma@community.com",
        },
        {
          id: "3",
          name: "Aman Tomar",
          role: "Maintenance Head",
          phone: "+91-9818196477",
          email: "aman.tomar@community.com",
        },
      ]
      setContacts(defaults)
      localStorage.setItem("contacts", JSON.stringify(defaults))
    }
  }, [])

  return (
    <section className="py-16 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <span className="text-2xl">📞</span>
          <h2 className="text-3xl font-bold text-foreground">Important Contacts</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-3 mb-8">
          {contacts.map((contact) => (
            <div
              key={contact.id}
              className="bg-muted rounded-lg border border-border overflow-hidden hover:shadow-lg transition p-6"
            >
              <h3 className="font-semibold text-foreground text-lg mb-1">{contact.name}</h3>
              <p className="text-sm text-primary font-medium mb-3">{contact.role}</p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <a
                  href={`tel:${contact.phone.replace(/[^\d+]/g, "")}`}
                  className="flex items-center gap-2 hover:text-primary transition"
                >
                  <span>📱</span>
                  <span>{contact.phone}</span>
                </a>
                <a href={`mailto:${contact.email}`} className="flex items-center gap-2 hover:text-primary transition">
                  <span>✉️</span>
                  <span>{contact.email}</span>
                </a>
              </div>
            </div>
          ))}
        </div>

        <Link
          href="/contacts"
          className="inline-block bg-primary text-background px-6 py-2 rounded-lg hover:bg-primary/90 transition font-medium"
        >
          View All Contacts
        </Link>
      </div>
    </section>
  )
}
