"use client"

import type React from "react"

import { useState } from "react"
import { Key } from "lucide-react"

interface AdminLoginProps {
  onLogin: () => void
}

export default function AdminLogin({ onLogin }: AdminLoginProps) {
  const [adminKey, setAdminKey] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (adminKey === "ADMIN-KEY-2024") {
      onLogin()
      setError("")
      setAdminKey("")
    } else {
      setError("Invalid admin key")
      setAdminKey("")
    }
  }

  return (
    <section className="py-12">
      <div className="max-w-md mx-auto px-4">
        <div className="bg-muted p-8 rounded-lg border border-border">
          <div className="flex justify-center mb-6">
            <div className="bg-primary text-background p-3 rounded-lg">
              <Key size={24} />
            </div>
          </div>
          <h1 className="text-2xl font-bold text-foreground text-center mb-2">Admin Access</h1>
          <p className="text-muted-foreground text-center mb-6">Enter your admin key to access the dashboard</p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">Admin Key</label>
              <input
                type="password"
                value={adminKey}
                onChange={(e) => setAdminKey(e.target.value)}
                placeholder="Enter admin key"
                className="w-full px-4 py-2 border border-border rounded-lg bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            {error && <p className="text-red-600 text-sm">{error}</p>}
            <button
              type="submit"
              className="w-full bg-primary text-background py-2 rounded-lg hover:bg-primary/90 transition font-medium"
            >
              Access Dashboard
            </button>
          </form>

         
        </div>
      </div>
    </section>
  )
}
