export default function Footer() {
  return (
    <footer className="bg-muted border-t border-border py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="font-semibold text-foreground mb-4">About</h3>
            <p className="text-muted-foreground text-sm">
              Community Notice Board helps residents stay connected and informed about community activities.
            </p>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">Quick Links</h3>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>
                <a href="/announcements" className="hover:text-primary transition">
                  Announcements
                </a>
              </li>
              <li>
                <a href="/events" className="hover:text-primary transition">
                  Events
                </a>
              </li>
              <li>
                <a href="/marketplace" className="hover:text-primary transition">
                  Marketplace
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-4">Contact</h3>
            <p className="text-muted-foreground text-sm">
              Email: info@communityboard.com
              <br />
              Phone: +91-1234567890
            </p>
          </div>
        </div>
        <div className="border-t border-border pt-8 text-center text-muted-foreground text-sm">
          <p>&copy; 2025 Community Notice Board. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
