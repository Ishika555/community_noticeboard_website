"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"

export default function Navigation() {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <nav className="sticky top-0 z-50 bg-background border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <span className="text-background font-bold text-sm">CB</span>
            </div>
            <span className="font-semibold text-foreground hidden sm:inline">Community Board</span>
          </Link>

          <div className="hidden md:flex gap-8">
            <Link href="/announcements" className="text-foreground hover:text-primary transition">
              Announcements
            </Link>
            <Link href="/events" className="text-foreground hover:text-primary transition">
              Events
            </Link>
            <Link href="/marketplace" className="text-foreground hover:text-primary transition">
              Buy/Sell/Rent
            </Link>
            <Link href="/contacts" className="text-foreground hover:text-primary transition">
              Contacts
            </Link>
            <Link href="/admin" className="text-foreground hover:text-primary transition">
              Admin
            </Link>
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="md:hidden p-2 hover:bg-muted rounded-lg transition">
            {isOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <Link href="/announcements" className="block px-4 py-2 text-foreground hover:bg-muted rounded">
              Announcements
            </Link>
            <Link href="/events" className="block px-4 py-2 text-foreground hover:bg-muted rounded">
              Events
            </Link>
            <Link href="/marketplace" className="block px-4 py-2 text-foreground hover:bg-muted rounded">
              Buy/Sell/Rent
            </Link>
            <Link href="/contacts" className="block px-4 py-2 text-foreground hover:bg-muted rounded">
              Contacts
            </Link>
            <Link href="/admin" className="block px-4 py-2 text-foreground hover:bg-muted rounded">
              Admin
            </Link>
          </div>
        )}
      </div>
    </nav>
  )
}
