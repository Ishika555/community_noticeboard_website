export default function Hero() {
  return (
    <section className="relative bg-gradient-to-br from-background to-muted py-16 md:py-24 overflow-hidden">
      <div className="absolute inset-0 opacity-10">
        <img src="/community-building-residential-society.jpg" alt="Community background" className="w-full h-full object-cover" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4 text-balance">Community Notice Board</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
          Stay connected with your community. Share announcements, events, and marketplace listings all in one place.
        </p>
      </div>
    </section>
  )
}
