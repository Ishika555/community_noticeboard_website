"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Calendar } from "lucide-react"

interface Event {
  id: string
  title: string
  date: string
  time: string
  location: string
  description: string
}

export default function EventsSection() {
  const [events, setEvents] = useState<Event[]>([])

  useEffect(() => {
    const stored = localStorage.getItem("events")
    if (stored) {
      setEvents(JSON.parse(stored))
    } else {
      const defaults: Event[] = [
        {
          id: "1",
          title: "Yoga Class",
          date: "2025-10-20",
          time: "6:00 AM",
          location: "Community Garden",
          description: "Morning yoga session for all fitness levels",
        },
        {
          id: "2",
          title: "Kids Sports Day",
          date: "2025-10-25",
          time: "3:00 PM",
          location: "Sports Ground",
          description: "Fun sports activities for children aged 5-12",
        },
      ]
      setEvents(defaults)
      localStorage.setItem("events", JSON.stringify(defaults))
    }
  }, [])

  return (
    <section className="py-16 bg-muted">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3 mb-8">
          <Calendar className="text-primary" size={28} />
          <h2 className="text-3xl font-bold text-foreground">Upcoming Events</h2>
        </div>

        <div className="grid gap-4 md:grid-cols-2 mb-8">
          {events.slice(0, 4).map((event) => (
            <div
              key={event.id}
              className="bg-background rounded-lg border border-border hover:shadow-lg transition overflow-hidden p-6"
            >
              <h3 className="font-semibold text-foreground text-lg mb-2">{event.title}</h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>📅 {new Date(event.date).toLocaleDateString()}</p>
                <p>🕐 {event.time}</p>
                <p>📍 {event.location}</p>
              </div>
              <p className="text-muted-foreground mt-3 line-clamp-2">{event.description}</p>
            </div>
          ))}
        </div>

        <Link
          href="/events"
          className="inline-block bg-primary text-background px-6 py-2 rounded-lg hover:bg-primary/90 transition font-medium"
        >
          View All Events
        </Link>
      </div>
    </section>
  )
}
